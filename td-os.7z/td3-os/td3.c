#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <stdio.h>
#include <pwd.h>
#include <dirent.h>
#include <string.h>

// ***********************
// ******* EXO 1 *********
// ***********************

// TYPE FICHIER
void afficheTypeFichier(const char* pathname){
	struct stat sb;
	
	if(stat(pathname,&sb) == -1) fprintf(stderr,"erreur stat \n");
	else{
		printf("Type de fichier : ");
		switch(sb.st_mode & S_IFMT){
			case S_IFBLK:	printf("périphérique de bloc\n"); 		break;
			case S_IFCHR:	printf("périphérique de caractère\n"); 	break;
			case S_IFDIR:	printf("répertoire\n"); 				break;
			case S_IFIFO:	printf("FIFO/tube\n"); 					break;
			case S_IFLNK:	printf("lien symbolique\n"); 			break;
			case S_IFREG:	printf("fichier ordinaire\n"); 			break;
			case S_IFSOCK:	printf("socket\n"); 					break;
			default: 		printf("inconnu ?\n");					break;
		}
	}
}

// ACCES FICHIER
void affichePermissionsFichier(const char* pathname){
	struct stat sb;
	if(stat(pathname,&sb) == -1) fprintf(stderr,"erreur stat \n");
	else{
		printf("Permissions fichier : ");
		if(sb.st_mode & S_IRUSR) printf("r"); 	else printf("_");
		if(sb.st_mode & S_IWUSR) printf("w"); 	else printf("_");
		if(sb.st_mode & S_IXUSR) printf("x"); 	else printf("_");
		if(sb.st_mode & S_IRGRP) printf("r"); 	else printf("_");
		if(sb.st_mode & S_IWGRP) printf("w"); 	else printf("_");
		if(sb.st_mode & S_IXGRP) printf("x"); 	else printf("_");
		if(sb.st_mode & S_IROTH) printf("r"); 	else printf("_");
		if(sb.st_mode & S_IWOTH) printf("w"); 	else printf("_");
		if(sb.st_mode & S_IXOTH) printf("x"); 	else printf("_");
		
		printf("\n");
	}
}

// PROPRIETAIRE FICHIER
void afficheProprietaireFichier(const char* pathname){
	struct stat sb;
	if(stat(pathname,&sb) == -1) fprintf(stderr,"erreur stat \n");
	else{
		struct passwd *pw = getpwuid(sb.st_uid);
		printf("username : %s \n",pw->pw_name);
	}
}

void afficheTailleFichier(const char* pathname){
	struct stat sb;
	if(stat(pathname,&sb) == -1) fprintf(stderr,"erreur stat \n");
	else{
		printf("Taille fichier : %ld o \n",sb.st_size);
	}
}

void afficheFichiers(const char* pathname){
	afficheTypeFichier(pathname);
	affichePermissionsFichier(pathname);
	afficheProprietaireFichier(pathname);
	afficheTailleFichier(pathname);
}

/* description
 * return information about a file, in the buffer pointed to by statbuf.
 * No permissions are required on the file
 * But permission is required on all of the directories in pathname that lead to the f
 * lstat : same as stat but if pathname is a symbolic link, then it
	returns information about the link itself, not the file that it refers to

 * stat structure
  * type :				 0170000 bit mask for the file type bit field
  * socket : 			 0140000 
  * symbolic link : 	 0120000
  * regular file : 		 0100000
  * block device : 		 0060000
  * directory : 		 0040000
  * character device : 	 0020000
  * FIFO : 				 0010000
 
 * return value
	Success : 0
	Error : -1

 * open
	*  0666
*/ 

// ***********************
// ******* EXO 2 *********
// ***********************
void afficheContenuRepertoire(const char* pathname){
	DIR* dir = opendir(pathname);
	if(dir == NULL) fprintf(stderr, "erreur ouverture fichier \n");
	
	struct dirent* d;
	printf("contenu du répertoire : ");
	while((d = readdir(dir)) != NULL){
		printf("%s ", d->d_name);
	}
	
	printf("\n");
	if(closedir(dir) == -1) fprintf(stderr, "erreur fermeture fichier \n");
}


int main(){
	afficheContenuRepertoire("../td3-os");
	return 0;
}

//~ int lstat(const char *pathname, struct stat *statbuf);
