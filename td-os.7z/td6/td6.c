#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>

typedef struct msg{
	int* id;
	pthread_mutex_t mutex;
	pthread_cond_t cond;
} MSG;

void* attendre(void* arg){
	MSG* m = (MSG*) arg;
	pthread_mutex_lock(&m->mutex);
	printf("entrée dans thread%d\n",*m->id);
	*m->id += 1;
	printf("id : %d\n",*m->id);
	if(*m->id > 1) pthread_cond_signal(&m->cond);
	pthread_cond_wait(&m->cond, &m->mutex);
	pthread_mutex_unlock(&m->mutex);
	
	printf("sortie thread precedent\n");
	pthread_exit(NULL);
}

void* signal(void*arg){
	MSG* m = (MSG*) arg;
	if(*m->id < 2){
		printf("attente thread2\n");
		pthread_mutex_lock(&m->mutex);
		pthread_cond_wait(&m->cond, &m->mutex);
		pthread_mutex_unlock(&m->mutex);
	}
	
	printf("sortie thread2\n");
	pthread_cond_broadcast(&m->cond);
	pthread_exit(NULL);
}

int main(){
	int i = 0;
	int n = 3;
	//~ pthread_t *tid = malloc(n*sizeof(pthread_t)); 
	MSG m;
	pthread_t *t = malloc(n*sizeof(pthread_t));
	
	pthread_mutex_t mtmp;
	pthread_mutex_init(&mtmp, NULL);
	pthread_cond_t ctmp;
	pthread_cond_init(&ctmp,NULL);
	
	m.mutex = mtmp;
	m.cond = ctmp;
	m.id = malloc(sizeof(int));
		
	for(i=0; i<n-1; i++){ 
		if(pthread_create(t+i, NULL, &attendre, &m)) printf("erreur creation thread\n");
		else printf("thread%d créé\n",i);
	}
	pthread_create(t+i, NULL, &signal, &m);
	
	for(i=0; i<n; i++){
		pthread_join(t[i],NULL);
	}
	
	return 0;
}
