#include <uvsqgraphics.h>

int main(){
	init_graphics(600,600);
	POINT p1,p2;
	p1 = wait_clic();
	p2 = wait_clic();
	draw_line(p1,p2,blanc);
	
	wait_escape();
	
	return 0;
}
