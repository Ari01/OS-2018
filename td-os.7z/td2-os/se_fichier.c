#include <stdlib.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>
#include "se_fichier.h"

// ouverture
SE_FICHIER SE_ouverture(const char * chemin, int acces){
	SE_FICHIER res;
	res.descripteur = open(chemin,acces,0666);
	res.chemin = strdup(chemin);
	res.acces = acces;
	
	return res;
}

// fermeture
int SE_fermeture(SE_FICHIER fichier){
	return close(fichier.descripteur);
}

// suppression
int SE_suppression (const char * chemin){
	return remove(chemin);
}

// lecture caractere
int SE_lectureCaractere (SE_FICHIER fichier, char * caractere){
	if(fichier.acces & (O_RDONLY | O_RDWR))
		return read(fichier.descripteur, caractere, sizeof(char));
	else fprintf(stderr,"erreur permissions");
	
	return -1;
}

// ecriture caractere
int SE_ecritureCaractere (SE_FICHIER fichier, const char caractere){
	if(fichier.acces & (O_WRONLY | O_RDWR))
		return write(fichier.descripteur, &caractere, sizeof(char));
	else fprintf(stderr,"erreur permissions");
	
	return -1;
}

// ####################################################################
// ##########################     EXO 3   #############################
// ####################################################################

// lecture chaine
int SE_lectureChaine (SE_FICHIER fichier, char * chaine, int tailleMax){
	if(fichier.acces & (O_RDONLY | O_RDWR))
		return read(fichier.descripteur, chaine, tailleMax);
	else fprintf(stderr,"erreur permissions");
	
	return -1;
}

int SE_ecritureChaine (SE_FICHIER fichier, const char * chaine, int taille){
	return 0;
}

int SE_lectureEntier (SE_FICHIER fichier, int * entier){
	return 0;
}
	
int SE_ecritureEntier (SE_FICHIER fichier, const int entier){
	return 0;
}

