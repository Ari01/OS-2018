#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <time.h>

void creerProcessus1(int m, int n){
	pid_t fils = 0;
	int cpt = 0;
	int i = n;
	int j = m;
	
	while(j){
		while(i){
			fils = fork();
			if(fils){
				i--;
				cpt++;
			}
			else exit(EXIT_SUCCESS);
		}
		
		i = n;
		j--;
	}
	j = m;
	
	while(j){
		i = n;
		while(i){
			wait(NULL);
			i--;
		}
		j--;
	}
	printf("%d\n",cpt);
}

void creerProcessus2(int m, int n){
	// var
	pid_t fils = 0;
	pid_t petitfils = 0;
	int i = n;
	int cptin = 0;
	int cptout = 0;
	int cpt = 0;
	
	// pipe
	int pipefd[2];
	if(pipe(pipefd)) printf("erreur creation pipe\n");
	
	// process
	while(m){
		// creation fils
		fils = fork();
		
		// fils
		if(!fils){
			if(close(pipefd[0])) printf("erreur fermeture sortie dans fils\n");
			// creation des petits fils
			while(i){
				petitfils = fork();
				if(!petitfils) exit(EXIT_SUCCESS);
				else{ 
					cptin++;			
					i--;
				}
			}
			for(i=0; i<n; i++){
				wait(NULL);
			}
			write(pipefd[1],&cptin,sizeof(int));
			exit(EXIT_SUCCESS);
		}
		
		// pere
		else{
			read(pipefd[0],&cptout,sizeof(int));
			
			cpt++;
			cpt += cptout;
			i = n;
			m--;
		}
	}
	for(i=0; i<m; i++){
		wait(NULL);
	}
	
	if(close(pipefd[1])) printf("erreur fermeture entrée dans pere\n");
	printf("cpt : %d\n",cpt);
}

int creerProcessus3(int m, int n){
	// var
	int i;
	int cptfils = 0;
	int cpt = 0;
	int status = 0;
	pid_t fils = 0;
	
	// arret
	if(!m) return 0;
	// creation processus
	else{
		for(i=0; i<n; i++){
			// creation fils
			fils = fork();
			if(!fils){
				printf("%d\n",getpid());
				cptfils = creerProcessus3(m-1,n);
				exit(cptfils+1);
			}
		}
		// wait
		for(i=0; i<n; i++){
			wait(&status);
			cpt += WEXITSTATUS(status); 
		}		
	}
	return cpt;
}

int main(){
	printf("total : %d\n",creerProcessus3(3,3));
	
	return 0;
}
