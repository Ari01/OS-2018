#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/times.h>
#include <time.h>

int main(){
	// on stocke la date initiale à l'aide de times
	struct tms t;
	printf("%ld\n",times(&t));
	int i = 0;
	while(i<100000000) i++;
	printf("%ld\n",times(&t));

	
	//~ // on créé un processus fils
	//~ pid_t fils = fork();
	
	//~ // si on est dans le fils, on fait system("ls");
	//~ // puis on sort du fils
	//~ if(!fils){
		//~ if(system("ls ~/ --recursive") == -1) printf("erreur commande systeme\n");
		//~ exit(EXIT_SUCCESS);
	//~ }

	//~ // on attend que le fils se termine, puis on affiche la différence 
	//~ wait(NULL);	
	//~ printf("%ld - %ld = %f\n",times(NULL),t0,(double)(times(NULL)-t0)/CLOCKS_PER_SEC);
	
	return 0;
}
