#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <time.h>

int main(){
	int i;
	int t = 0;
	pid_t fils = 0;
	srand(time(NULL));
	
	for(i=1; i<11; i++){
		t = rand()%9 + 1;
		fils = fork();
		
		if(!fils){
			sleep(t);
			printf("fils%d : mon pid est %d\n",i,getpid());
			printf("n secondes attendues : %d secondes\n",t);
			exit(EXIT_SUCCESS);
		}
	}
	for(i=0; i<10; i++){
		printf("fils se terminant : %d\n", wait(NULL));
	}
	
	return 0;
}
