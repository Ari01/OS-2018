#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/times.h>
#include <time.h>

int main(){
	int i;
	pid_t fils = fork();
	
	if(fils){
		for(i=3; i>=0; i--){
			sleep(1);
			printf("pause fils dans : %d\n",i);
		}
		kill(fils,SIGSTOP);
		
		for(i=4; i>=0; i--){
			sleep(1);
			printf("reprise fils dans : %d\n",i);
		}
		kill(fils,SIGCONT);
		wait(NULL);
	}
	else{
		for(i=1; i<6; i++){
			sleep(1);
			printf("comptage fils : %d\n",i);
		}
		exit(0);
	}
}
