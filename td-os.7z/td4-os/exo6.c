#include <unistd.h>
#include <time.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <stdio.h>
#include <signal.h>

int sec = 0;

void handler(int i){
	printf("debug : %d\n",sec);
}

void gestionSignal(){
	struct sigaction sa;
	sa.sa_flags = SA_ONSTACK;
	sa.sa_handler = handler;
	
	pid_t fils = fork();
	for(sec=1; sec<13; sec++){	
		sleep(1);	
		if(!fils){
			if(sigaction(SIGUSR1,&sa,NULL)){ 
				printf("erreur sigaction\n");
			}
			printf("%d\n",sec);
		}
		else{
			if(sec == 3 || sec == 5 || sec == 8){
				kill(fils,SIGUSR1);
			}
		}
	}
	
	if(!fils) exit(EXIT_SUCCESS);
	wait(NULL);
}

int main(){
	gestionSignal();
	return 0;
}
