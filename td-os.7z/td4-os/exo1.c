#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <time.h>

void HW(){
	printf("Hello World !\n");
}

void affichePID(pid_t fils){	
	if(fils)
		printf("Mon PID est %d, celui de mon père est %d et celui de mon fils est %d \n",getpid(),getppid(), fils);
	else
		printf("Mon PID est %d et celui de mon père est %d \n",getpid(),getppid());
}

//~ int pipefd[]
void alea_int(pid_t fils){
	if(!fils){
		//~ close(pipefd[0]); // fermeture sortie tube
		int x = rand()%49 + 1;
		printf("fils : %d\n",x);
		
		//~ write(pipefd[1],&x,sizeof(int)); // ecriture entrée tube
		exit(x);
	}
}

int main(){
	srand(time(NULL));
	int y = 0;
	// creation pipe
	//~ int pipefd[2];
	//~ if(pipe(pipefd)){
		 //~ printf("erreur creation pipe \n");
		 //~ exit(EXIT_FAILURE);
	 //~ }
	
	// creation processus
	pid_t fils = fork();
	//~ pipefd
	alea_int(fils);
	wait(&y);
	printf("%d\n",WEXITSTATUS(y));
		
	//~ close(pipefd[1]);					// fermeture entrée tube
	//~ read(pipefd[0],&y,sizeof(int));		// lecture sortie tube
	//~ printf("pere : %d\n",y);
		
	return 0;
}
