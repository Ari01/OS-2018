#include <pthread.h>
#include <sys/types.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define N 10

// FONCTIONS MAIN
// entier aleatoire
int rand100(){
	return rand()%10;
}

// creer thread
pthread_t creerThread(void* (*fonction)(void*arg), void* arg){
	pthread_t threadHW;
	
	// creation du thread
	if(pthread_create(&threadHW,NULL,fonction,arg)){
		perror("pthread_create");
	}
	
	// attendre fin thread
	if(pthread_join(threadHW,NULL)){
		perror("pthread_join");
	}
}

//tableau de n entiers
void* tabEntiers(int t[]){
	t = malloc(N*sizeof(int));
	int i;
	for(i=0; i<N;i++){
		t[i] = rand100();
		printf("%d \n",t[i]);
	}
	
	return t;
}

// FONCTIONS THREAD
// affichage HW
void* afficheHW(void *arg){
	printf("Hello world ! \n");
	pthread_exit(NULL);
}

// affichage entier aléatoire
void* afficheEntier(void *arg){
	int *i = arg;
	printf("entier généré par le processus principal : %d \n",*i);
	pthread_exit(NULL);
}

// affichage entier aléatoire généré dans le thread
void* afficheEntierThread(void* arg){
	int* i = arg;
	*i = rand100();
	printf("thread : entier généré par le thread : %d \n",*i);
	pthread_exit(NULL);
}

// affichage moyenne tab
void* afficheMoyenneTab(void* arg){
	int *tab = arg;
	int i,moy;
	moy = 0;
	
	for(i=0; i<N; i++){
		moy += tab[i];
	}
	
	printf("moyenne : %d \n",moy/i);
	pthread_exit(NULL);
}

// MAIN
int main(){
	srand(time(NULL)); //rand
	int *r = malloc(sizeof(void*));
	*r = rand100();
	
	creerThread(afficheHW,NULL); // HW
	creerThread(afficheEntier,(void*)r); // var alea
	creerThread(afficheEntierThread,(void*)r);
	printf("main : entier généré par le thread : %d \n",*r);
	
	int *t = NULL;
	t = tabEntiers(t);
	creerThread(afficheMoyenneTab,(t));
	
	free(r);
	return EXIT_SUCCESS;
}
