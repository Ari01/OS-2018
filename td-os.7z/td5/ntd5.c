#include <pthread.h>
#include <stdlib.h>
#include <stdio.h>
#include <time.h>

#define N 10

typedef struct tab{
	int* tableau;
	int taille;
} TAB;

void* helloWorld(void* arg){
	printf("Hello World !\n");
	pthread_exit(NULL);
}

void* aleaInt(void* arg){
	int* a = arg;
	printf("%d\n",*a);
	pthread_exit(NULL);
}

void* aleaInt2(void* arg){
	int* a = malloc(sizeof(int));
	*a = rand()%10;
	printf("%d\n",*a);
	pthread_exit(a);
}



TAB init_tab(int taille){
	int i;
	TAB t;
	
	t.tableau = malloc(taille*sizeof(int));
	t.taille = taille;
	
	for(i=0; i<t.taille; i++){
		t.tableau[i] = rand()%10;
	}
	
	return t;
}

void affiche_tab(TAB t){
	int i;
	for(i=0; i<t.taille; i++){
		printf("%d\n",t.tableau[i]);
	}
}

void* moyenneTableau(void* arg){
	int i;
	int moyenne = 0;
	int* t = arg;
	
	for(i=0; i<N; i++){
		moyenne += t[i];
	}

	pthread_exit(NULL);
}

int main(){
	srand(time(NULL));
	TAB t = init_tab(N);
	affiche_tab(t);
	
	//~ int* t = malloc(sizeof(int));
	//~ *t = rand()%10;
	//~ void* res = malloc(sizeof(int));
	
	//~ pthread_t HW;
	//~ pthread_create(&HW,NULL,helloWorld,NULL);
	//~ pthread_join(HW,NULL);
	
	//~ pthread_t alea;
	//~ pthread_create(&alea,NULL,aleaInt,t);
	//~ pthread_join(alea,NULL);
	
	//~ pthread_t alea2;
	//~ pthread_create(&alea2,NULL,aleaInt2,NULL);
	//~ pthread_join(alea2,&res);
	//~ t = res;
	//~ printf("%d\n",*t);
	
	pthread_t moyenne;
	pthread_create(&moyenne,NULL,moyenneTableau,t.tableau);
	pthread_join(moyenne,NULL);
	
	//~ free(res);
	return 0;
}
