#include <stdlib.h>

int main(int argc, char*argv[]){
	system(argv[1]);
	exit(0);
}

//~ man chdir ? ne prends pas en compte le ~
// mathieu tribalat
